import os
import json
import requests
from datetime import datetime
from loguru import logger
from CanojaVerifyPymysqlWrapper import CanojaVerifyPymysqlWrapper
from CanojaTechLogUtils import *

def main(event, context):
    logger.info("Starting Lambda execution")

    # Get the current date in YYYY-MM-DD format
    current_date = datetime.now().strftime("%Y-%m-%d")
   
    # Database Variables
    mysql_db_endpoint = os.environ['mysql_db_endpoint']
    mysql_db_username = os.environ['mysql_db_username']
    mysql_db_password = os.environ['mysql_db_password']
    mysql_db_name = os.environ['mysql_db_name']
    mysql_db_port = '3306'

    # Other Variables
    teams_webhook_url = os.environ['teams_webhook_url']
    etl_environment = os.environ['etl_environment']    

    # ETL Database-State Mappings
    etl_db_state_mappings = {
        "CanojaVerifyPythonEtl": ["mo", "pr", "ny", "il", "ct", "oh"],
        "CanojaVerifyEtl": ["ak", "ca", "co", "ma", "mi", "nv", "ok", "or"]
        # Add other ETL databases and their corresponding states as needed
    }

    # Create summary variables
    old_records = 0
    added_records = 0
    updated_records = 0
    deleted_records = 0
    new_records = []  # List to aggregate new records

    try:
        logger.info("Connecting to database")
        db_obj = CanojaVerifyPymysqlWrapper(mysql_db_endpoint, mysql_db_username, mysql_db_password, mysql_db_name, mysql_db_port)
        db_obj.connect_to_mysql()

        # Query the initial total number of records in the PROD database
        old_records = get_total_records_count(db_obj, etl_db_state_mappings)

        for etl_db_name, states in etl_db_state_mappings.items():
            for state in states:
                logger.info(f"Processing state: {state} from ETL database: {etl_db_name}")

                # Fetch and process current records from prod for the specific state
                current_records_sql = f"SELECT * FROM CanojaVerifyLicenseDb.LicenseInformation WHERE businessState = %s"
                current_records = db_obj.do_query(current_records_sql, (state,))
                current_records_dict = {row[1]: convert_prod_row_to_dict(row) for row in current_records}
                current_records_set = {row[1] for row in current_records}

                # Process ETL data for the specific state from the specific ETL database
                insert_batch, etl_records_set, updated_records_local, new_records_local = process_etl_data(db_obj, state, etl_db_name, current_records_set, current_records_dict)

                # Perform batch insert for new records
                if insert_batch:
                    logger.info("Performing batch insert")
                    batch_insert(db_obj, insert_batch)

                # Identify and delete records not present in ETL dataset
                deleted_records_batch = current_records_set - etl_records_set
                for licenseNumber in deleted_records_batch:
                    logger.info(f"Deleting record for licenseNumber: {licenseNumber}")
                    delete_sql, data = generate_delete_sql(licenseNumber, state)
                    db_obj.do_delete(delete_sql, data)
                    deleted_records += 1

                # Aggregate counts and new records
                updated_records += updated_records_local
                added_records += len(insert_batch)
                new_records.extend(new_records_local)

        # After all operations, query the total number of records in the PROD database
        total_records_after_etl = get_total_records_count(db_obj, etl_db_state_mappings)

        db_obj.disconnect_to_mysql()

        # Format the ETL summary as a dictionary
        etl_summary = {
            "Old Records": old_records,
            "Added Records": added_records,
            "Updated Records": updated_records,
            "Deleted Records": deleted_records,
            "Total Records After ETL": total_records_after_etl
        }

        # Append the current date to the title
        etl_environment = os.environ.get('etl_environment', 'Unknown Environment')
        title = f"ETL Process Summary - {etl_environment} ({current_date})"

        # Send the summary to Teams using Adaptive Card
        send_to_teams(teams_webhook_url, title, etl_summary)
        
    except Exception as e:
        logger.error(f"ERROR: Unexpected error: {e}")
        return str(e)
    
    return title

def process_etl_data(db_obj, state, etl_db_name, current_records_set, current_records_dict):
    logger.info(f"Processing ETL data from database: {etl_db_name} for state: {state}")
    updated_records_local = 0
    new_records_local = []  # List to track new records

    etl_records_sql = f"SELECT * FROM {etl_db_name}.LicenseInformation WHERE businessState = %s"
    etl_records = db_obj.do_query(etl_records_sql, (state,))
    etl_records_set = {row[0] for row in etl_records}
    insert_batch = []

    for row in etl_records:
        etl_rec = convert_etl_row_to_dict(row)
        if etl_rec["licenseNumber"] in current_records_set:
            current_rec = current_records_dict[etl_rec["licenseNumber"]]
            if records_differ(etl_rec, current_rec):
                logger.info(f"Updating record for licenseNumber: {etl_rec['licenseNumber']}")
                update_sql, data = generate_update_sql(etl_rec, state)
                db_obj.do_update(update_sql, data)
                updated_records_local += 1
            else:
                pass
                # logger.info(f"No update needed for licenseNumber: {etl_rec['licenseNumber']}")
        else:
            insert_batch.append(etl_rec)
            new_records_local.append(etl_rec["licenseNumber"])  # Add the new record's licenseNumber to the list

    return insert_batch, etl_records_set, updated_records_local, new_records_local


def records_differ(etl_rec, current_rec):
    fields_to_compare = ['licenseCategory', 'licenseType', 'licenseStatus', 
                         'licenseIssueDate', 'licenseExpireDate', 'licenseOwner', 
                         'retail', 'medical', 'businessLegalName', 'businessDoingBusinessAs', 
                         'businessAddress1', 'businessAddress2', 'businessCity', 
                         'businessCounty', 'businessZipcode', 'businessCountry', 
                         'businessPhoneNumber', 'businessEmailAddress', 'businessStructure']

    for field in fields_to_compare:
        if etl_rec[field] != current_rec[field]:
            logger.debug(f"Field {field} differs. ETL: {etl_rec[field]}, Prod: {current_rec[field]}")
            return True
    return False

def convert_etl_row_to_dict(row):
    return {
        'licenseNumber': row[0],
        'licenseCategory': row[1],
        'licenseType': row[2],
        'licenseStatus': row[3],
        'licenseIssueDate': row[4],
        'licenseExpireDate': row[5],
        'licenseOwner': row[6],
        'retail': row[7],
        'medical': row[8],
        'businessLegalName': row[9],
        'businessDoingBusinessAs': row[10],
        'businessAddress1': row[11],
        'businessAddress2': row[12],
        'businessCity': row[13],
        'businessCounty': row[14],
        'businessState': row[15],
        'businessZipcode': row[16],
        'businessCountry': row[17],
        'businessPhoneNumber': row[18],
        'businessEmailAddress': row[19],
        'businessStructure': row[20],
        'active': row[21],
        'csvRowUniqueKey': row[22],
        'refreshedOn': row[23]
    }

def convert_prod_row_to_dict(row):
    return {
        'id': row[0],  # Assuming the first column is an ID in the prod database
        'licenseNumber': row[1],
        'licenseCategory': row[2],
        'licenseType': row[3],
        'licenseStatus': row[4],
        'licenseIssueDate': row[5],
        'licenseExpireDate': row[6],
        'licenseOwner': row[7],
        'retail': row[8],
        'medical': row[9],
        'businessLegalName': row[10],
        'businessDoingBusinessAs': row[11],
        'businessAddress1': row[12],
        'businessAddress2': row[13],
        'businessCity': row[14],
        'businessCounty': row[15],
        'businessState': row[16],
        'businessZipcode': row[17],
        'businessCountry': row[18],
        'businessPhoneNumber': row[19],
        'businessEmailAddress': row[20],
        'businessStructure': row[21],
        'active': row[22],
        'csvRowUniqueKey': row[23],
        'refreshed_on': row[24]  # Note: 'refreshed_on' for prod database
    }

def batch_insert(db_obj, insert_batch):
    if not insert_batch:
        return

    # SQL statement for inserting a single record
    single_insert_sql = '''
        ( %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s )
    '''

    # Construct the full INSERT query with multiple value placeholders
    values_placeholders = ', '.join([single_insert_sql] * len(insert_batch))
    insert_sql = f'''
        INSERT INTO CanojaVerifyLicenseDb.LicenseInformation
        (licenseNumber, licenseCategory, licenseType, licenseStatus, licenseIssueDate, 
         licenseExpireDate, licenseOwner, retail, medical, businessLegalName, businessDoingBusinessAs, 
         businessAddress1, businessAddress2, businessCity, businessCounty, businessState, businessZipcode, 
         businessCountry, businessPhoneNumber, businessEmailAddress, businessStructure, active, 
         csvRowUniqueKey, refreshed_on)
        VALUES {values_placeholders}
    '''

    # Flatten the list of tuples for the execute_sql method
    values = [item for sublist in insert_batch for item in sublist]

    # Execute the batch insert
    db_obj.execute_sql(insert_sql, values, 'insert')

def batch_update(db_obj, update_batch, businessState):
    for rec in update_batch:
        update_sql, data = generate_update_sql(rec, businessState)
        db_obj.execute_sql(update_sql, data, 'update')

def generate_update_sql(etl_rec, businessState):
    update_sql = '''
        UPDATE CanojaVerifyLicenseDb.LicenseInformation
        SET
            licenseCategory = %s,
            licenseType = %s,
            licenseStatus = %s,
            licenseIssueDate = %s,
            licenseExpireDate = %s,
            licenseOwner = %s,
            retail = %s,
            medical = %s,
            businessLegalName = %s,
            businessDoingBusinessAs = %s,
            businessAddress1 = %s,
            businessAddress2 = %s,
            businessCity = %s,
            businessCounty = %s,
            businessZipcode = %s,
            businessCountry = %s,
            businessPhoneNumber = %s,
            businessEmailAddress = %s,
            businessStructure = %s,
            active = %s,
            csvRowUniqueKey = %s,
            refreshed_on = %s
        WHERE licenseNumber = %s AND businessState = %s
    '''
    data = (
        etl_rec["licenseCategory"],
        etl_rec["licenseType"],
        etl_rec["licenseStatus"],
        etl_rec["licenseIssueDate"],
        etl_rec["licenseExpireDate"],
        etl_rec["licenseOwner"],
        etl_rec["retail"],
        etl_rec["medical"],
        etl_rec["businessLegalName"],
        etl_rec["businessDoingBusinessAs"],
        etl_rec["businessAddress1"],
        etl_rec["businessAddress2"],
        etl_rec["businessCity"],
        etl_rec["businessCounty"],
        etl_rec["businessZipcode"],
        etl_rec["businessCountry"],
        etl_rec["businessPhoneNumber"],
        etl_rec["businessEmailAddress"],
        etl_rec["businessStructure"],
        etl_rec["active"],
        etl_rec["csvRowUniqueKey"],
        etl_rec["refreshedOn"],
        etl_rec["licenseNumber"],
        businessState
    )
    return update_sql, data


def generate_insert_sql(etl_rec, businessState):
    insert_sql = '''
        INSERT INTO CanojaVerifyLicenseDb.LicenseInformation
        (licenseNumber, licenseCategory, licenseType, licenseStatus, licenseIssueDate, 
        licenseExpireDate, licenseOwner, retail, medical, businessLegalName, businessDoingBusinessAs, 
        businessAddress1, businessAddress2, businessCity, businessCounty, businessState, businessZipcode, 
        businessCountry, businessPhoneNumber, businessEmailAddress, businessStructure, active, 
        csvRowUniqueKey, refreshed_on)
        VALUES
        (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    '''
    data = (
        etl_rec["licenseNumber"],
        etl_rec["licenseCategory"],
        etl_rec["licenseType"],
        etl_rec["licenseStatus"],
        etl_rec["licenseIssueDate"],
        etl_rec["licenseExpireDate"],
        etl_rec["licenseOwner"],
        etl_rec["retail"],
        etl_rec["medical"],
        etl_rec["businessLegalName"],
        etl_rec["businessDoingBusinessAs"],
        etl_rec["businessAddress1"],
        etl_rec["businessAddress2"],
        etl_rec["businessCity"],
        etl_rec["businessCounty"],
        businessState,
        etl_rec["businessZipcode"],
        etl_rec["businessCountry"],
        etl_rec["businessPhoneNumber"],
        etl_rec["businessEmailAddress"],
        etl_rec["businessStructure"],
        etl_rec["active"],
        etl_rec["csvRowUniqueKey"],
        etl_rec["refreshedOn"]
    )
    return insert_sql, data

def generate_delete_sql(licenseNumber, businessState):
    delete_sql = "DELETE FROM CanojaVerifyLicenseDb.LicenseInformation WHERE licenseNumber = %s AND businessState = %s"
    return delete_sql, (licenseNumber, businessState)

def format_date(date):
    return f"'{date.isoformat()}'" if date is not None else 'NULL'

def get_total_records_count(db_obj, etl_db_state_mappings):
    total_count = 0
    for states in etl_db_state_mappings.values():
        for state in states:
            count_sql = f"SELECT COUNT(*) FROM CanojaVerifyLicenseDb.LicenseInformation WHERE businessState = %s"
            count_result = db_obj.do_query(count_sql, (state,))
            total_count += count_result[0][0] if count_result else 0
    return total_count

def send_to_teams(webhook_url, title, etl_summary):
    headers = {"Content-Type": "application/json"}

    # Construct the Adaptive Card payload with a table-like layout
    card_content = {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": None,
                "content": {
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard",
                    "version": "1.2",
                    "body": [
                        {
                            "type": "TextBlock",
                            "size": "Medium",
                            "weight": "Bolder",
                            "text": title
                        },
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": 1,
                                    "items": [
                                        {"type": "TextBlock", "weight": "Bolder", "text": "Records", "wrap": True}
                                    ] + [{"type": "TextBlock", "text": key, "wrap": True} for key in etl_summary]
                                },
                                {
                                    "type": "Column",
                                    "width": 1,
                                    "items": [
                                        {"type": "TextBlock", "weight": "Bolder", "text": "Count", "wrap": True}
                                    ] + [{"type": "TextBlock", "text": str(etl_summary[key]), "wrap": True} for key in etl_summary]
                                }
                            ]
                        }
                    ]
                }
            }
        ]
    }

    response = requests.post(webhook_url, headers=headers, data=json.dumps(card_content))
    if response.status_code != 200:
        logger.error(f"Failed to send message to Teams. Status Code: {response.status_code}, Response: {response.text}")

# Main
if __name__ == "__main__":
    main(None, None)