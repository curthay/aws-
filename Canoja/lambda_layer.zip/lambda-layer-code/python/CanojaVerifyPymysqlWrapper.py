from loguru import logger
import pymysql

class CanojaVerifyPymysqlWrapper:
    def __init__(self, host, user, password, database, port):
        self.connected = False
        self.db_handle = None
        self.host = host
        self.user = user
        self.password = password
        self.database = database
        self.port = int(port)
        logger.debug(f'__init__() success, host={self.host}, user={self.user}, database={self.database}, port={self.port}')

    def __del__(self):
        self.disconnect_to_mysql()

    def __enter__(self):
        self.connect_to_mysql()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.disconnect_to_mysql()

    def connect_to_mysql(self):
        if self.connected:
            return True
        try:
            self.db_handle = pymysql.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database,
                port=self.port
            )
            self.connected = True
            logger.debug(f'Connect to MySQL Server success, host={self.host}, user={self.user}, database={self.database}, port={self.port}')
            return True
        except Exception as e:
            logger.warning(f'Connect to MySQL Server Failed, errmsg={e}')
            return False

    def disconnect_to_mysql(self):
        try:
            if self.connected and self.db_handle is not None:
                self.db_handle.close()
                self.db_handle = None
                self.connected = False
                logger.debug(f'Disconnect from MySQL Server success, host={self.host}, user={self.user}, database={self.database}, port={self.port}')
        except Exception as e:
            logger.warning(f'Disconnect from MySQL Server Failed, errmsg={e}')

    def ensure_connection(self):
        if not self.connected or self.db_handle is None:
            if not self.connect_to_mysql():
                raise ConnectionError('Could not connect to the database')

    def execute_sql(self, sql_cmd, data, operation):
        try:
            self.ensure_connection()
            with self.db_handle.cursor() as cursor:
                cursor.execute(sql_cmd, data)
                if operation == 'query':
                    return cursor.fetchall()
                else:
                    self.db_handle.commit()
                    return cursor.rowcount
        except Exception as e:
            logger.error(f'{operation.capitalize()} operation failed, errmsg={e}')
            return None

    def do_query(self, sql_cmd, data=()):
        return self.execute_sql(sql_cmd, data, 'query')

    def do_insert(self, sql_cmd, data):
        return self.execute_sql(sql_cmd, data, 'insert')

    def do_update(self, sql_cmd, data):
        return self.execute_sql(sql_cmd, data, 'update')

    def do_delete(self, sql_cmd, data):
        return self.execute_sql(sql_cmd, data, 'delete')
